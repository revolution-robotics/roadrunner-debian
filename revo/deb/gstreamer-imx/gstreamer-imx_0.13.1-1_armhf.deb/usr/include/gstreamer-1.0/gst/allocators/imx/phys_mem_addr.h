#ifndef GST_IMX_COMMON_PHYS_MEM_ADDR_H
#define GST_IMX_COMMON_PHYS_MEM_ADDR_H


#define GST_IMX_PHYS_ADDR_FORMAT "#lx"

typedef unsigned long gst_imx_phys_addr_t;


#endif
