/* version.c: Version definition for the ed line editor.
 *
 * Copyright © 1993-2022 Andrew L. Moore, SlewSys Research
 *
 * This file is part of ed.
 */

#include "config.h"

char version_string[] = VERSION;
