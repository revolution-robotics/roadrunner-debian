E script-e5
r !echo %
/H/;+d
wq e5.o
script-e5
