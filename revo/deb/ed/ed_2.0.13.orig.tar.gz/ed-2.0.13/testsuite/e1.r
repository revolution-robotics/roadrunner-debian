E script-e1
/H/;+d
wq e1.o
