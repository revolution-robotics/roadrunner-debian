line 1
line 2
line 3
line 4
line5
r script-r3
/H/;+d
wq r3.o
