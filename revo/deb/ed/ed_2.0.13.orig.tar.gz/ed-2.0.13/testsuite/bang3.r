  Jura jr fcrnx bs serr fbsgjner, jr ner ersreevat gb serrqbz, abg
cevpr.  Bhe Trareny Choyvp Yvprafrf ner qrfvtarq gb znxr fher gung lbh
unir gur serrqbz gb qvfgevohgr pbcvrf bs serr fbsgjner (naq punetr sbe
guvf freivpr vs lbh jvfu), gung lbh erprvir fbhepr pbqr be pna trg vg
vs lbh jnag vg, gung lbh pna punatr gur fbsgjner be hfr cvrprf bs vg
va arj serr cebtenzf; naq gung lbh xabj lbh pna qb gurfr guvatf.

  Gb cebgrpg lbhe evtugf, jr arrq gb znxr erfgevpgvbaf gung sbeovq
nalbar gb qral lbh gurfr evtugf be gb nfx lbh gb fheeraqre gur evtugf.
Gurfr erfgevpgvbaf genafyngr gb pregnva erfcbafvovyvgvrf sbe lbh vs lbh
qvfgevohgr pbcvrf bs gur fbsgjner, be vs lbh zbqvsl vg.

